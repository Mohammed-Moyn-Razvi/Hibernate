package mbs.Online_Medical_booking_store;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Admin_module {

	static int id;
	static boolean login(String u, String p)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		String select = "SELECT  a FROM admin a WHERE username=:username and password=:password";

		
			Query query = em.createQuery(select);
				query.setParameter("username", u);
				query.setParameter("password", p);
				
    if(query.getResultList().size() == 0){
        System.out.println("Account does not exist!");
        return false;
    }
    else
    {
        System.out.println("Login Success!");
        admin login = (admin) query.getSingleResult(); 
        id =login.getId();
        return true;
    }
	}
	
	public static void main(String[] args) {
		System.out.println("Enter the credentials");
		Scanner s=new Scanner(System.in);
		if(login(s.next(),s.next()))
		{
			System.out.println("Shall we Begin");
			String choice=s.next();
			while(choice.equals("Y"))
			{
			System.out.println("Select your module"
					+"1: user"
					+"2: Products");
			switch(s.nextByte())
			{
			case 1: System.out.println("Please select the options");
						System.out.println("1: view"
								+ "2: Delete");
						switch(s.nextByte())
						{
						case 1:
								System.out.println("The users are:-");
								view_users();
						break;
						
						case 2:
									System.out.println("Please enter the id:");
									int id=s.nextInt();
									del_user(id);
									System.out.println("The user has been succesfully deleted");
					
						break;
						default:System.out.println("Beg your Pardon");
						}
						break;
			case 2: System.out.println("Please select the options");
			{
				System.out.println("1: view"
						+ "2: Add"
						+ "3: Modify"
						+ "4: Delete");
				switch(s.nextByte())
				{
				case 1:{
						System.out.println("The products present int the inventory are");
						view_products();
						}break;
				case 2:{
						System.out.println("Please Enter the product details");
						add_product();
				}break;
				case 3:
				{
					System.out.println("Please enter the product id:");
					int id=s.nextInt();
					modify_product(id);
				}break;
				case 4: 
				{
					System.out.println("Please enter the product id:");
					int id=s.nextInt();
					del_product(id);
				}
				break;
				default:System.out.println("Beg your Pardon");
				}
				
			}break;
			default:System.out.println("Beg your Pardon");
			
			}
			}
		}
		}
	private static void del_product(int id) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		Products p=new Products();
		p.setId(id);
		em.remove(p);
		
		et.commit();
	}
	private static void modify_product(int id) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		Scanner s=new Scanner(System.in);
		Products p=em.find(Products.class, id);
		System.out.println("Please select the data to be modified\n"
				+ "1: Stock\n"
				+ "2: Price\n"
				+ "3: Severity\n");
		switch(s.nextInt())
		{
		case 1:p.setStock(s.nextInt());break;
		case 2:p.setPrice(s.nextDouble());break;
		case 3:p.setSeverity(s.next());break;
		default: System.out.println("Invalid option");
		}
		
		em.persist(p);
		et.commit();
		
	}
	private static void add_product() {

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		Scanner s=new Scanner(System.in);
		Products p=new Products();
		System.out.println("Enter the id");
		p.setId(s.nextInt());
		System.out.println("Enter the name");
		p.setName(s.next());
		System.out.println("Enter the product Supplier");
		p.setSupplier(s.next());
		System.out.println("Enter the price");
		p.setPrice(s.nextDouble());
		System.out.println("Enter the medicine severity");
		p.setSeverity(s.next());
		System.out.println("Enter the Stock quantity");
		p.setStock(s.nextInt());
		
		em.persist(p);
		et.commit();
	}
	private static void view_users() {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		String q="select u from User u";
		Query query = em.createQuery(q);
		List<User> l=query.getResultList();
		for(User u:l)
			System.out.println(u);
		
		
	}
	private static void del_user(int id) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		User p=new User();
		p.setId(id);
		em.remove(p);
		
		et.commit();
	}
	private static void view_products() {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		String q="select p from Products p";
		Query query = em.createQuery(q);
		List<Products> l=query.getResultList();
		for(Products u:l)
			System.out.println(u);
	}
	
	
	
	
	
}
