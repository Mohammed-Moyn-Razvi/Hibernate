package mbs.Online_Medical_booking_store;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Visitors {
	
	public static void main(String[] args) {
		
		
		System.out.println("Welcome to the page..."
				+ "\nPlease select the options\n"
				+ "1: View Medicines\n"
				+ "2: Login\n"
				+ "3: Register/Signup\n");
		Scanner s=new Scanner(System.in);
		
		switch(s.nextInt())
		{
		case 1 : System.out.println("The products available are");
		 			User_module.view();
		 			break;
		case 2 : System.out.println("Please enter your login details");
					User_module.main(null);
					break;
		case 3 : System.out.println("Please fill up the form for signing up");
		 			register();
					break;
		default:System.out.println("Beg your Pardon");	
		}
		
	}

	private static void register() {
		Scanner s=new Scanner(System.in);
		User u=new User();
		System.out.println("Enter the id");
		u.setId(s.nextInt());
		System.out.println("Enter the name");
		u.setName(s.next());
		System.out.println("Enter the DoB in dd-mm-yyyy format");
		u.setDOB(s.next());
		System.out.println("Enter the email id");
		u.setEmail(s.next());
		System.out.println("Enter the phone number");
		u.setPhone_no(s.nextLong());
		System.out.println("Enter your password");
		u.setPassword(s.next());
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		em.persist(u);
		et.commit();
		
	}

}
