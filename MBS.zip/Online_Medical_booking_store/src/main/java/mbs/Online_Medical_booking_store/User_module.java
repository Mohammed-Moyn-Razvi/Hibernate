package mbs.Online_Medical_booking_store;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class User_module {
	
	static int id;
	static List<Products> l=new ArrayList<Products>();
	static boolean login(String u, String p)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		String select = "SELECT u FROM User u WHERE email=:username and password=:password";

		
			Query query = em.createQuery(select);
				query.setParameter("username", u);
				query.setParameter("password", p);
				
    if(query.getResultList().size() == 0){
    	
        System.out.println("Account does not exist!");
        return false;
    }
    else
    {
        System.out.println("Login Success!");
        User login = (User) query.getSingleResult(); 
        System.out.println(login.getName());
        id =login.getId();
        return true;
    }
	}
	public static void main(String[] args) {
		System.out.println("Enter the credentials");
		Scanner s=new Scanner(System.in);
		
		if(login(s.next(),s.next()))
		{
			System.out.println("Shall we Begin");
			String choice=s.next();
			while(choice.equals("Y"))
			{
			System.out.println("Select your options"
					+ "1: view products"
					+ "2: Create order"
					+ "3: Place the order"
					+ "4: Modify your details"
					+ "5: Logout");
			switch(s.nextInt())
			{
			case 1:System.out.println("the products are:");
					view();
				break;
			case 2:System.out.println("Shall we begin..!");
					choice=s.next();
					while(s.next().equals("Y"))
					{
						System.out.println("Please enter the product's ids");
			   		int pid=s.nextInt();
			   		add_into_bill(pid);
			   		System.out.println("do you want to continue...!");
					}
					
					break;
			case 3:{
				System.out.println("Please enter your previous password");
				String op=s.next();
				System.out.println("Enter the new password");
				String np=s.next();
				System.out.println("Could you please confirm your password");
				String cp=s.next();
				if(cp.equals(np))
					update_pass(np);
				else
					System.out.println("Sorry..! Password not matching");

			}break;
			case 5:System.out.println("Thank you for visiting....");
			 		return;
			default:System.out.println("Beg your Pardon");
			}
		}
	}
	}
	static void view() {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		String q="select p from Products p";
		Query query = em.createQuery(q);
		List<Products> l=query.getResultList();
		for(Products u:l)
			System.out.println(u);
	}
	private static void update_pass(String np) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		String q="select u from User u where id="+id;
		Query query = em.createQuery(q);
		List<User> l=query.getResultList();
		for(User u:l)
			u.setPassword(np);;
	}

	private static void add_into_bill(int pid) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		
		Products p=em.find(Products.class, pid);
		User u=em.find(User.class, id);
		
		l.add(p);
		u.setL(l);
		em.persist(p);
		et.commit();
	}
}
