package mbs.Online_Medical_booking_store;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class User {
	@Id
	private int id;
	private String name;
	private long phone_no;
	private String DOB;
	private String email;
	private String password;
	
	@OneToMany
	private List<Products> l=new ArrayList<Products>();
	
	
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", phone_no=" + phone_no + ", DOB=" + DOB + ", email=" + email
				+ ", password=" + password + "]\n";
	}
	public List<Products> getL() {
		return l;
	}
	public void setL(List<Products> l) {
		this.l = l;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(long phone_no) {
		this.phone_no = phone_no;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
